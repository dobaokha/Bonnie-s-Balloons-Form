﻿namespace Do_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.balloonsPictureBox = new System.Windows.Forms.PictureBox();
            this.companyNameLabel = new System.Windows.Forms.Label();
            this.customerInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.stateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.zipMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.titleComboBox = new System.Windows.Forms.ComboBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.phoneNumberMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.streetTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.zipLabel = new System.Windows.Forms.Label();
            this.stateLabel = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.streetLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.deliveryGroupBox = new System.Windows.Forms.GroupBox();
            this.homeDeliveryPriceLabel = new System.Windows.Forms.Label();
            this.homeDeliveryRadioButton = new System.Windows.Forms.RadioButton();
            this.pickupRadioButton = new System.Windows.Forms.RadioButton();
            this.deliveryTypeLabel = new System.Windows.Forms.Label();
            this.deliveryDateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.deliveryDateLabel = new System.Windows.Forms.Label();
            this.orderGroupBox = new System.Windows.Forms.GroupBox();
            this.messageInstructionLabel = new System.Windows.Forms.Label();
            this.personalizedMessagePriceLabel = new System.Windows.Forms.Label();
            this.customMessageTextBox = new System.Windows.Forms.TextBox();
            this.customMessageLabel = new System.Windows.Forms.Label();
            this.personalizedcardCheckBox = new System.Windows.Forms.CheckBox();
            this.extraItemPriceLabel = new System.Windows.Forms.Label();
            this.extraListBox = new System.Windows.Forms.ListBox();
            this.extraLabel = new System.Windows.Forms.Label();
            this.specialOccasionComboBox = new System.Windows.Forms.ComboBox();
            this.specialOccasionLabel = new System.Windows.Forms.Label();
            this.dozenPriceLabel = new System.Windows.Forms.Label();
            this.dozenRadioButton = new System.Windows.Forms.RadioButton();
            this.halfDozenPriceLabel = new System.Windows.Forms.Label();
            this.halfDozenRadioButton = new System.Windows.Forms.RadioButton();
            this.singlePriceLabel = new System.Windows.Forms.Label();
            this.singleRadioButton = new System.Windows.Forms.RadioButton();
            this.bundleSizeLabel = new System.Windows.Forms.Label();
            this.orderTotalGroupBox = new System.Windows.Forms.GroupBox();
            this.taxRateLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.totalLabel = new System.Windows.Forms.Label();
            this.totalPromptLabel = new System.Windows.Forms.Label();
            this.salesTaxLabel = new System.Windows.Forms.Label();
            this.salesTaxPrompLabel = new System.Windows.Forms.Label();
            this.subtotalLabel = new System.Windows.Forms.Label();
            this.subtotalPromptLabel = new System.Windows.Forms.Label();
            this.displaySummaryButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.balloonsPictureBox)).BeginInit();
            this.customerInformationGroupBox.SuspendLayout();
            this.deliveryGroupBox.SuspendLayout();
            this.orderGroupBox.SuspendLayout();
            this.orderTotalGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // balloonsPictureBox
            // 
            this.balloonsPictureBox.Image = global::Do_3.Properties.Resources.balloons;
            this.balloonsPictureBox.Location = new System.Drawing.Point(327, 13);
            this.balloonsPictureBox.Name = "balloonsPictureBox";
            this.balloonsPictureBox.Size = new System.Drawing.Size(72, 80);
            this.balloonsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.balloonsPictureBox.TabIndex = 0;
            this.balloonsPictureBox.TabStop = false;
            // 
            // companyNameLabel
            // 
            this.companyNameLabel.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.companyNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.companyNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyNameLabel.ForeColor = System.Drawing.Color.SaddleBrown;
            this.companyNameLabel.Location = new System.Drawing.Point(429, 18);
            this.companyNameLabel.Name = "companyNameLabel";
            this.companyNameLabel.Size = new System.Drawing.Size(356, 71);
            this.companyNameLabel.TabIndex = 0;
            this.companyNameLabel.Text = "Bonnie\'s Balloons";
            this.companyNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customerInformationGroupBox
            // 
            this.customerInformationGroupBox.Controls.Add(this.stateMaskedTextBox);
            this.customerInformationGroupBox.Controls.Add(this.zipMaskedTextBox);
            this.customerInformationGroupBox.Controls.Add(this.titleComboBox);
            this.customerInformationGroupBox.Controls.Add(this.titleLabel);
            this.customerInformationGroupBox.Controls.Add(this.phoneNumberMaskedTextBox);
            this.customerInformationGroupBox.Controls.Add(this.cityTextBox);
            this.customerInformationGroupBox.Controls.Add(this.streetTextBox);
            this.customerInformationGroupBox.Controls.Add(this.lastNameTextBox);
            this.customerInformationGroupBox.Controls.Add(this.firstNameTextBox);
            this.customerInformationGroupBox.Controls.Add(this.phoneLabel);
            this.customerInformationGroupBox.Controls.Add(this.zipLabel);
            this.customerInformationGroupBox.Controls.Add(this.stateLabel);
            this.customerInformationGroupBox.Controls.Add(this.cityLabel);
            this.customerInformationGroupBox.Controls.Add(this.streetLabel);
            this.customerInformationGroupBox.Controls.Add(this.lastNameLabel);
            this.customerInformationGroupBox.Controls.Add(this.firstNameLabel);
            this.customerInformationGroupBox.Location = new System.Drawing.Point(502, 109);
            this.customerInformationGroupBox.Name = "customerInformationGroupBox";
            this.customerInformationGroupBox.Size = new System.Drawing.Size(453, 239);
            this.customerInformationGroupBox.TabIndex = 3;
            this.customerInformationGroupBox.TabStop = false;
            this.customerInformationGroupBox.Text = "Customer Information";
            // 
            // stateMaskedTextBox
            // 
            this.stateMaskedTextBox.Location = new System.Drawing.Point(222, 148);
            this.stateMaskedTextBox.Mask = ">LL";
            this.stateMaskedTextBox.Name = "stateMaskedTextBox";
            this.stateMaskedTextBox.Size = new System.Drawing.Size(53, 22);
            this.stateMaskedTextBox.TabIndex = 11;
            this.stateMaskedTextBox.ValidatingType = typeof(int);
            // 
            // zipMaskedTextBox
            // 
            this.zipMaskedTextBox.Location = new System.Drawing.Point(50, 184);
            this.zipMaskedTextBox.Mask = "00000";
            this.zipMaskedTextBox.Name = "zipMaskedTextBox";
            this.zipMaskedTextBox.Size = new System.Drawing.Size(53, 22);
            this.zipMaskedTextBox.TabIndex = 13;
            this.zipMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.zipMaskedTextBox.ValidatingType = typeof(int);
            // 
            // titleComboBox
            // 
            this.titleComboBox.FormattingEnabled = true;
            this.titleComboBox.Items.AddRange(new object[] {
            "Dr.",
            "Mr.",
            "Mrs.",
            "Ms.",
            "Rev."});
            this.titleComboBox.Location = new System.Drawing.Point(54, 28);
            this.titleComboBox.Name = "titleComboBox";
            this.titleComboBox.Size = new System.Drawing.Size(70, 24);
            this.titleComboBox.TabIndex = 1;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(9, 31);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(39, 17);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Title:";
            // 
            // phoneNumberMaskedTextBox
            // 
            this.phoneNumberMaskedTextBox.Location = new System.Drawing.Point(284, 190);
            this.phoneNumberMaskedTextBox.Mask = "(999) 000-0000";
            this.phoneNumberMaskedTextBox.Name = "phoneNumberMaskedTextBox";
            this.phoneNumberMaskedTextBox.Size = new System.Drawing.Size(104, 22);
            this.phoneNumberMaskedTextBox.TabIndex = 15;
            this.phoneNumberMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(50, 145);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(100, 22);
            this.cityTextBox.TabIndex = 9;
            // 
            // streetTextBox
            // 
            this.streetTextBox.Location = new System.Drawing.Point(65, 107);
            this.streetTextBox.Name = "streetTextBox";
            this.streetTextBox.Size = new System.Drawing.Size(349, 22);
            this.streetTextBox.TabIndex = 7;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(314, 69);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.lastNameTextBox.TabIndex = 5;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(95, 66);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.firstNameTextBox.TabIndex = 3;
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(171, 190);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(112, 17);
            this.phoneLabel.TabIndex = 14;
            this.phoneLabel.Text = "Phone Number:*";
            // 
            // zipLabel
            // 
            this.zipLabel.AutoSize = true;
            this.zipLabel.Location = new System.Drawing.Point(9, 187);
            this.zipLabel.Name = "zipLabel";
            this.zipLabel.Size = new System.Drawing.Size(32, 17);
            this.zipLabel.TabIndex = 12;
            this.zipLabel.Text = "Zip:";
            // 
            // stateLabel
            // 
            this.stateLabel.AutoSize = true;
            this.stateLabel.Location = new System.Drawing.Point(171, 148);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(45, 17);
            this.stateLabel.TabIndex = 10;
            this.stateLabel.Text = "State:";
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Location = new System.Drawing.Point(9, 148);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(35, 17);
            this.cityLabel.TabIndex = 8;
            this.cityLabel.Text = "City:";
            // 
            // streetLabel
            // 
            this.streetLabel.AutoSize = true;
            this.streetLabel.Location = new System.Drawing.Point(9, 109);
            this.streetLabel.Name = "streetLabel";
            this.streetLabel.Size = new System.Drawing.Size(50, 17);
            this.streetLabel.TabIndex = 6;
            this.streetLabel.Text = "Street:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(228, 69);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(85, 17);
            this.lastNameLabel.TabIndex = 4;
            this.lastNameLabel.Text = "Last Name:*";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(9, 70);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(85, 17);
            this.firstNameLabel.TabIndex = 2;
            this.firstNameLabel.Text = "First Name:*";
            // 
            // deliveryGroupBox
            // 
            this.deliveryGroupBox.Controls.Add(this.homeDeliveryPriceLabel);
            this.deliveryGroupBox.Controls.Add(this.homeDeliveryRadioButton);
            this.deliveryGroupBox.Controls.Add(this.pickupRadioButton);
            this.deliveryGroupBox.Controls.Add(this.deliveryTypeLabel);
            this.deliveryGroupBox.Controls.Add(this.deliveryDateMaskedTextBox);
            this.deliveryGroupBox.Controls.Add(this.deliveryDateLabel);
            this.deliveryGroupBox.Location = new System.Drawing.Point(23, 109);
            this.deliveryGroupBox.Name = "deliveryGroupBox";
            this.deliveryGroupBox.Size = new System.Drawing.Size(453, 108);
            this.deliveryGroupBox.TabIndex = 2;
            this.deliveryGroupBox.TabStop = false;
            this.deliveryGroupBox.Text = "Delivery Information";
            // 
            // homeDeliveryPriceLabel
            // 
            this.homeDeliveryPriceLabel.AutoSize = true;
            this.homeDeliveryPriceLabel.Location = new System.Drawing.Point(349, 71);
            this.homeDeliveryPriceLabel.Name = "homeDeliveryPriceLabel";
            this.homeDeliveryPriceLabel.Size = new System.Drawing.Size(48, 17);
            this.homeDeliveryPriceLabel.TabIndex = 5;
            this.homeDeliveryPriceLabel.Text = "PRICE";
            // 
            // homeDeliveryRadioButton
            // 
            this.homeDeliveryRadioButton.AutoSize = true;
            this.homeDeliveryRadioButton.Location = new System.Drawing.Point(222, 69);
            this.homeDeliveryRadioButton.Name = "homeDeliveryRadioButton";
            this.homeDeliveryRadioButton.Size = new System.Drawing.Size(121, 21);
            this.homeDeliveryRadioButton.TabIndex = 4;
            this.homeDeliveryRadioButton.TabStop = true;
            this.homeDeliveryRadioButton.Text = "Home Delivery";
            this.homeDeliveryRadioButton.UseVisualStyleBackColor = true;
            // 
            // pickupRadioButton
            // 
            this.pickupRadioButton.AutoSize = true;
            this.pickupRadioButton.Location = new System.Drawing.Point(116, 69);
            this.pickupRadioButton.Name = "pickupRadioButton";
            this.pickupRadioButton.Size = new System.Drawing.Size(76, 21);
            this.pickupRadioButton.TabIndex = 3;
            this.pickupRadioButton.TabStop = true;
            this.pickupRadioButton.Text = "Pick-up";
            this.pickupRadioButton.UseVisualStyleBackColor = true;
            this.pickupRadioButton.CheckedChanged += new System.EventHandler(this.pickupRadioButton_CheckedChanged);
            // 
            // deliveryTypeLabel
            // 
            this.deliveryTypeLabel.AutoSize = true;
            this.deliveryTypeLabel.Location = new System.Drawing.Point(9, 71);
            this.deliveryTypeLabel.Name = "deliveryTypeLabel";
            this.deliveryTypeLabel.Size = new System.Drawing.Size(99, 17);
            this.deliveryTypeLabel.TabIndex = 2;
            this.deliveryTypeLabel.Text = "Delivery Type:";
            // 
            // deliveryDateMaskedTextBox
            // 
            this.deliveryDateMaskedTextBox.Location = new System.Drawing.Point(116, 31);
            this.deliveryDateMaskedTextBox.Mask = "00/00/0000";
            this.deliveryDateMaskedTextBox.Name = "deliveryDateMaskedTextBox";
            this.deliveryDateMaskedTextBox.Size = new System.Drawing.Size(100, 22);
            this.deliveryDateMaskedTextBox.TabIndex = 1;
            this.deliveryDateMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.deliveryDateMaskedTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // deliveryDateLabel
            // 
            this.deliveryDateLabel.AutoSize = true;
            this.deliveryDateLabel.Location = new System.Drawing.Point(9, 31);
            this.deliveryDateLabel.Name = "deliveryDateLabel";
            this.deliveryDateLabel.Size = new System.Drawing.Size(97, 17);
            this.deliveryDateLabel.TabIndex = 0;
            this.deliveryDateLabel.Text = "Delivery Date:";
            // 
            // orderGroupBox
            // 
            this.orderGroupBox.Controls.Add(this.messageInstructionLabel);
            this.orderGroupBox.Controls.Add(this.personalizedMessagePriceLabel);
            this.orderGroupBox.Controls.Add(this.customMessageTextBox);
            this.orderGroupBox.Controls.Add(this.customMessageLabel);
            this.orderGroupBox.Controls.Add(this.personalizedcardCheckBox);
            this.orderGroupBox.Controls.Add(this.extraItemPriceLabel);
            this.orderGroupBox.Controls.Add(this.extraListBox);
            this.orderGroupBox.Controls.Add(this.extraLabel);
            this.orderGroupBox.Controls.Add(this.specialOccasionComboBox);
            this.orderGroupBox.Controls.Add(this.specialOccasionLabel);
            this.orderGroupBox.Controls.Add(this.dozenPriceLabel);
            this.orderGroupBox.Controls.Add(this.dozenRadioButton);
            this.orderGroupBox.Controls.Add(this.halfDozenPriceLabel);
            this.orderGroupBox.Controls.Add(this.halfDozenRadioButton);
            this.orderGroupBox.Controls.Add(this.singlePriceLabel);
            this.orderGroupBox.Controls.Add(this.singleRadioButton);
            this.orderGroupBox.Controls.Add(this.bundleSizeLabel);
            this.orderGroupBox.Location = new System.Drawing.Point(23, 242);
            this.orderGroupBox.Name = "orderGroupBox";
            this.orderGroupBox.Size = new System.Drawing.Size(453, 417);
            this.orderGroupBox.TabIndex = 1;
            this.orderGroupBox.TabStop = false;
            this.orderGroupBox.Text = "Order Details";
            // 
            // messageInstructionLabel
            // 
            this.messageInstructionLabel.AutoSize = true;
            this.messageInstructionLabel.ForeColor = System.Drawing.Color.Red;
            this.messageInstructionLabel.Location = new System.Drawing.Point(138, 340);
            this.messageInstructionLabel.Name = "messageInstructionLabel";
            this.messageInstructionLabel.Size = new System.Drawing.Size(101, 17);
            this.messageInstructionLabel.TabIndex = 15;
            this.messageInstructionLabel.Text = "INSTRUCTION";
            // 
            // personalizedMessagePriceLabel
            // 
            this.personalizedMessagePriceLabel.AutoSize = true;
            this.personalizedMessagePriceLabel.Location = new System.Drawing.Point(283, 302);
            this.personalizedMessagePriceLabel.Name = "personalizedMessagePriceLabel";
            this.personalizedMessagePriceLabel.Size = new System.Drawing.Size(48, 17);
            this.personalizedMessagePriceLabel.TabIndex = 13;
            this.personalizedMessagePriceLabel.Text = "PRICE";
            // 
            // customMessageTextBox
            // 
            this.customMessageTextBox.Location = new System.Drawing.Point(12, 368);
            this.customMessageTextBox.MaxLength = 30;
            this.customMessageTextBox.Name = "customMessageTextBox";
            this.customMessageTextBox.Size = new System.Drawing.Size(421, 22);
            this.customMessageTextBox.TabIndex = 16;
            // 
            // customMessageLabel
            // 
            this.customMessageLabel.AutoSize = true;
            this.customMessageLabel.Location = new System.Drawing.Point(9, 340);
            this.customMessageLabel.Name = "customMessageLabel";
            this.customMessageLabel.Size = new System.Drawing.Size(120, 17);
            this.customMessageLabel.TabIndex = 14;
            this.customMessageLabel.Text = "Custom Message:";
            // 
            // personalizedcardCheckBox
            // 
            this.personalizedcardCheckBox.AutoSize = true;
            this.personalizedcardCheckBox.Location = new System.Drawing.Point(12, 300);
            this.personalizedcardCheckBox.Name = "personalizedcardCheckBox";
            this.personalizedcardCheckBox.Size = new System.Drawing.Size(265, 21);
            this.personalizedcardCheckBox.TabIndex = 12;
            this.personalizedcardCheckBox.Text = "Include a personalized message card";
            this.personalizedcardCheckBox.UseVisualStyleBackColor = true;
            this.personalizedcardCheckBox.CheckedChanged += new System.EventHandler(this.personalizedcardCheckBox_CheckedChanged);
            // 
            // extraItemPriceLabel
            // 
            this.extraItemPriceLabel.AutoSize = true;
            this.extraItemPriceLabel.Location = new System.Drawing.Point(9, 205);
            this.extraItemPriceLabel.Name = "extraItemPriceLabel";
            this.extraItemPriceLabel.Size = new System.Drawing.Size(103, 17);
            this.extraItemPriceLabel.TabIndex = 11;
            this.extraItemPriceLabel.Text = "PRICE per Item";
            // 
            // extraListBox
            // 
            this.extraListBox.FormattingEnabled = true;
            this.extraListBox.ItemHeight = 16;
            this.extraListBox.Location = new System.Drawing.Point(125, 178);
            this.extraListBox.Name = "extraListBox";
            this.extraListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.extraListBox.Size = new System.Drawing.Size(153, 100);
            this.extraListBox.TabIndex = 10;
            this.extraListBox.SelectedIndexChanged += new System.EventHandler(this.extraListBox_SelectedIndexChanged);
            // 
            // extraLabel
            // 
            this.extraLabel.AutoSize = true;
            this.extraLabel.Location = new System.Drawing.Point(9, 178);
            this.extraLabel.Name = "extraLabel";
            this.extraLabel.Size = new System.Drawing.Size(81, 17);
            this.extraLabel.TabIndex = 9;
            this.extraLabel.Text = "Extra Items:";
            // 
            // specialOccasionComboBox
            // 
            this.specialOccasionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.specialOccasionComboBox.FormattingEnabled = true;
            this.specialOccasionComboBox.Location = new System.Drawing.Point(137, 138);
            this.specialOccasionComboBox.Name = "specialOccasionComboBox";
            this.specialOccasionComboBox.Size = new System.Drawing.Size(149, 24);
            this.specialOccasionComboBox.TabIndex = 8;
            // 
            // specialOccasionLabel
            // 
            this.specialOccasionLabel.AutoSize = true;
            this.specialOccasionLabel.Location = new System.Drawing.Point(9, 142);
            this.specialOccasionLabel.Name = "specialOccasionLabel";
            this.specialOccasionLabel.Size = new System.Drawing.Size(121, 17);
            this.specialOccasionLabel.TabIndex = 7;
            this.specialOccasionLabel.Text = "Special Occasion:";
            // 
            // dozenPriceLabel
            // 
            this.dozenPriceLabel.AutoSize = true;
            this.dozenPriceLabel.Location = new System.Drawing.Point(193, 106);
            this.dozenPriceLabel.Name = "dozenPriceLabel";
            this.dozenPriceLabel.Size = new System.Drawing.Size(48, 17);
            this.dozenPriceLabel.TabIndex = 6;
            this.dozenPriceLabel.Text = "PRICE";
            // 
            // dozenRadioButton
            // 
            this.dozenRadioButton.AutoSize = true;
            this.dozenRadioButton.Location = new System.Drawing.Point(116, 104);
            this.dozenRadioButton.Name = "dozenRadioButton";
            this.dozenRadioButton.Size = new System.Drawing.Size(70, 21);
            this.dozenRadioButton.TabIndex = 5;
            this.dozenRadioButton.TabStop = true;
            this.dozenRadioButton.Text = "Dozen";
            this.dozenRadioButton.UseVisualStyleBackColor = true;
            // 
            // halfDozenPriceLabel
            // 
            this.halfDozenPriceLabel.AutoSize = true;
            this.halfDozenPriceLabel.Location = new System.Drawing.Point(220, 69);
            this.halfDozenPriceLabel.Name = "halfDozenPriceLabel";
            this.halfDozenPriceLabel.Size = new System.Drawing.Size(48, 17);
            this.halfDozenPriceLabel.TabIndex = 4;
            this.halfDozenPriceLabel.Text = "PRICE";
            // 
            // halfDozenRadioButton
            // 
            this.halfDozenRadioButton.AutoSize = true;
            this.halfDozenRadioButton.Location = new System.Drawing.Point(116, 67);
            this.halfDozenRadioButton.Name = "halfDozenRadioButton";
            this.halfDozenRadioButton.Size = new System.Drawing.Size(98, 21);
            this.halfDozenRadioButton.TabIndex = 3;
            this.halfDozenRadioButton.TabStop = true;
            this.halfDozenRadioButton.Text = "Half-dozen";
            this.halfDozenRadioButton.UseVisualStyleBackColor = true;
            this.halfDozenRadioButton.CheckedChanged += new System.EventHandler(this.halfDozenRadioButton_CheckedChanged);
            // 
            // singlePriceLabel
            // 
            this.singlePriceLabel.AutoSize = true;
            this.singlePriceLabel.Location = new System.Drawing.Point(190, 33);
            this.singlePriceLabel.Name = "singlePriceLabel";
            this.singlePriceLabel.Size = new System.Drawing.Size(48, 17);
            this.singlePriceLabel.TabIndex = 2;
            this.singlePriceLabel.Text = "PRICE";
            // 
            // singleRadioButton
            // 
            this.singleRadioButton.AutoSize = true;
            this.singleRadioButton.Location = new System.Drawing.Point(116, 31);
            this.singleRadioButton.Name = "singleRadioButton";
            this.singleRadioButton.Size = new System.Drawing.Size(68, 21);
            this.singleRadioButton.TabIndex = 1;
            this.singleRadioButton.TabStop = true;
            this.singleRadioButton.Text = "Single";
            this.singleRadioButton.UseVisualStyleBackColor = true;
            this.singleRadioButton.CheckedChanged += new System.EventHandler(this.singleRadioButton_CheckedChanged);
            // 
            // bundleSizeLabel
            // 
            this.bundleSizeLabel.AutoSize = true;
            this.bundleSizeLabel.Location = new System.Drawing.Point(9, 33);
            this.bundleSizeLabel.Name = "bundleSizeLabel";
            this.bundleSizeLabel.Size = new System.Drawing.Size(87, 17);
            this.bundleSizeLabel.TabIndex = 0;
            this.bundleSizeLabel.Text = "Bundle Size:";
            // 
            // orderTotalGroupBox
            // 
            this.orderTotalGroupBox.Controls.Add(this.taxRateLabel);
            this.orderTotalGroupBox.Controls.Add(this.groupBox1);
            this.orderTotalGroupBox.Controls.Add(this.totalLabel);
            this.orderTotalGroupBox.Controls.Add(this.totalPromptLabel);
            this.orderTotalGroupBox.Controls.Add(this.salesTaxLabel);
            this.orderTotalGroupBox.Controls.Add(this.salesTaxPrompLabel);
            this.orderTotalGroupBox.Controls.Add(this.subtotalLabel);
            this.orderTotalGroupBox.Controls.Add(this.subtotalPromptLabel);
            this.orderTotalGroupBox.Location = new System.Drawing.Point(502, 366);
            this.orderTotalGroupBox.Name = "orderTotalGroupBox";
            this.orderTotalGroupBox.Size = new System.Drawing.Size(453, 293);
            this.orderTotalGroupBox.TabIndex = 4;
            this.orderTotalGroupBox.TabStop = false;
            this.orderTotalGroupBox.Text = "Order Totals";
            // 
            // taxRateLabel
            // 
            this.taxRateLabel.AutoSize = true;
            this.taxRateLabel.Location = new System.Drawing.Point(137, 111);
            this.taxRateLabel.Name = "taxRateLabel";
            this.taxRateLabel.Size = new System.Drawing.Size(35, 17);
            this.taxRateLabel.TabIndex = 3;
            this.taxRateLabel.Text = "TAX";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(222, 152);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(100, 3);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(222, 174);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(100, 23);
            this.totalLabel.TabIndex = 7;
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalPromptLabel
            // 
            this.totalPromptLabel.AutoSize = true;
            this.totalPromptLabel.Location = new System.Drawing.Point(151, 177);
            this.totalPromptLabel.Name = "totalPromptLabel";
            this.totalPromptLabel.Size = new System.Drawing.Size(44, 17);
            this.totalPromptLabel.TabIndex = 6;
            this.totalPromptLabel.Text = "Total:";
            // 
            // salesTaxLabel
            // 
            this.salesTaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesTaxLabel.Location = new System.Drawing.Point(222, 108);
            this.salesTaxLabel.Name = "salesTaxLabel";
            this.salesTaxLabel.Size = new System.Drawing.Size(100, 23);
            this.salesTaxLabel.TabIndex = 4;
            this.salesTaxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // salesTaxPrompLabel
            // 
            this.salesTaxPrompLabel.AutoSize = true;
            this.salesTaxPrompLabel.Location = new System.Drawing.Point(62, 111);
            this.salesTaxPrompLabel.Name = "salesTaxPrompLabel";
            this.salesTaxPrompLabel.Size = new System.Drawing.Size(74, 17);
            this.salesTaxPrompLabel.TabIndex = 2;
            this.salesTaxPrompLabel.Text = "Sales Tax:";
            // 
            // subtotalLabel
            // 
            this.subtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.subtotalLabel.Location = new System.Drawing.Point(222, 69);
            this.subtotalLabel.Name = "subtotalLabel";
            this.subtotalLabel.Size = new System.Drawing.Size(100, 23);
            this.subtotalLabel.TabIndex = 1;
            this.subtotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // subtotalPromptLabel
            // 
            this.subtotalPromptLabel.AutoSize = true;
            this.subtotalPromptLabel.Location = new System.Drawing.Point(131, 72);
            this.subtotalPromptLabel.Name = "subtotalPromptLabel";
            this.subtotalPromptLabel.Size = new System.Drawing.Size(64, 17);
            this.subtotalPromptLabel.TabIndex = 0;
            this.subtotalPromptLabel.Text = "Subtotal:";
            // 
            // displaySummaryButton
            // 
            this.displaySummaryButton.Location = new System.Drawing.Point(345, 675);
            this.displaySummaryButton.Name = "displaySummaryButton";
            this.displaySummaryButton.Size = new System.Drawing.Size(100, 55);
            this.displaySummaryButton.TabIndex = 5;
            this.displaySummaryButton.Text = "&Display Summary";
            this.toolTip.SetToolTip(this.displaySummaryButton, "The summary of all the information in the program");
            this.displaySummaryButton.UseVisualStyleBackColor = true;
            this.displaySummaryButton.Click += new System.EventHandler(this.displaySummaryButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(461, 675);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(100, 55);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "&Clear";
            this.toolTip.SetToolTip(this.clearButton, "Reset the program to its original state.");
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(574, 675);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(100, 55);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "E&xit";
            this.toolTip.SetToolTip(this.exitButton, "Close the program");
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 752);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displaySummaryButton);
            this.Controls.Add(this.orderTotalGroupBox);
            this.Controls.Add(this.orderGroupBox);
            this.Controls.Add(this.deliveryGroupBox);
            this.Controls.Add(this.customerInformationGroupBox);
            this.Controls.Add(this.companyNameLabel);
            this.Controls.Add(this.balloonsPictureBox);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bonnie\'s Balloons Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.balloonsPictureBox)).EndInit();
            this.customerInformationGroupBox.ResumeLayout(false);
            this.customerInformationGroupBox.PerformLayout();
            this.deliveryGroupBox.ResumeLayout(false);
            this.deliveryGroupBox.PerformLayout();
            this.orderGroupBox.ResumeLayout(false);
            this.orderGroupBox.PerformLayout();
            this.orderTotalGroupBox.ResumeLayout(false);
            this.orderTotalGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox balloonsPictureBox;
        private System.Windows.Forms.Label companyNameLabel;
        private System.Windows.Forms.GroupBox customerInformationGroupBox;
        private System.Windows.Forms.ComboBox titleComboBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.MaskedTextBox phoneNumberMaskedTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox streetTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label zipLabel;
        private System.Windows.Forms.Label stateLabel;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.Label streetLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.GroupBox deliveryGroupBox;
        private System.Windows.Forms.GroupBox orderGroupBox;
        private System.Windows.Forms.GroupBox orderTotalGroupBox;
        private System.Windows.Forms.MaskedTextBox deliveryDateMaskedTextBox;
        private System.Windows.Forms.Label deliveryDateLabel;
        private System.Windows.Forms.RadioButton homeDeliveryRadioButton;
        private System.Windows.Forms.RadioButton pickupRadioButton;
        private System.Windows.Forms.Label deliveryTypeLabel;
        private System.Windows.Forms.Label homeDeliveryPriceLabel;
        private System.Windows.Forms.Label dozenPriceLabel;
        private System.Windows.Forms.RadioButton dozenRadioButton;
        private System.Windows.Forms.Label halfDozenPriceLabel;
        private System.Windows.Forms.RadioButton halfDozenRadioButton;
        private System.Windows.Forms.Label singlePriceLabel;
        private System.Windows.Forms.RadioButton singleRadioButton;
        private System.Windows.Forms.Label bundleSizeLabel;
        private System.Windows.Forms.Label specialOccasionLabel;
        private System.Windows.Forms.ComboBox specialOccasionComboBox;
        private System.Windows.Forms.Label extraLabel;
        private System.Windows.Forms.ListBox extraListBox;
        private System.Windows.Forms.Label extraItemPriceLabel;
        private System.Windows.Forms.Label personalizedMessagePriceLabel;
        private System.Windows.Forms.TextBox customMessageTextBox;
        private System.Windows.Forms.Label customMessageLabel;
        private System.Windows.Forms.CheckBox personalizedcardCheckBox;
        private System.Windows.Forms.Label messageInstructionLabel;
        private System.Windows.Forms.Label subtotalLabel;
        private System.Windows.Forms.Label subtotalPromptLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label totalPromptLabel;
        private System.Windows.Forms.Label salesTaxLabel;
        private System.Windows.Forms.Label salesTaxPrompLabel;
        private System.Windows.Forms.Label taxRateLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button displaySummaryButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.MaskedTextBox zipMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox stateMaskedTextBox;
    }
}

